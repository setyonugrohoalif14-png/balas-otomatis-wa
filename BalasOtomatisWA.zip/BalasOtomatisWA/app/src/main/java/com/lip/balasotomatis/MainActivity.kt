package com.lip.balasotomatis

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var adapter: ArrayAdapter<Aturan>
    private lateinit var txtStatus: TextView
    private lateinit var txtKosong: TextView
    private lateinit var editJeda: EditText
    private lateinit var editUsia: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val list = findViewById<ListView>(R.id.listAturan)
        val header = LayoutInflater.from(this).inflate(R.layout.header_main, list, false)
        list.addHeaderView(header, null, false)

        val switchAktif = header.findViewById<Switch>(R.id.switchAktif)
        val btnAkses = header.findViewById<Button>(R.id.btnAkses)
        val btnTambah = header.findViewById<Button>(R.id.btnTambah)
        txtStatus = header.findViewById(R.id.txtStatusAkses)
        txtKosong = header.findViewById(R.id.txtKosong)
        editJeda = header.findViewById(R.id.editJeda)
        editUsia = header.findViewById(R.id.editUsia)

        switchAktif.isChecked = Store.aktif(this)
        editJeda.setText(Store.jedaMenit(this).toString())
        editUsia.setText(Store.usiaMaksMenit(this).toString())

        switchAktif.setOnCheckedChangeListener { _, v -> Store.setAktif(this, v) }

        btnAkses.setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }

        btnTambah.setOnClickListener {
            startActivity(Intent(this, RuleEditActivity::class.java))
        }

        adapter = object : ArrayAdapter<Aturan>(
            this, android.R.layout.simple_list_item_2, android.R.id.text1
        ) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = super.getView(position, convertView, parent)
                val a = getItem(position) ?: return v
                v.findViewById<TextView>(android.R.id.text1).text =
                    (if (a.aktif) "" else "[nonaktif] ") + "\"${a.kata}\""
                v.findViewById<TextView>(android.R.id.text2).text = ringkas(a)
                return v
            }
        }
        list.adapter = adapter

        // Mengetuk aturan membuka layar ubah. Tidak ada tombol hapus di daftar ini.
        list.setOnItemClickListener { parent, _, position, _ ->
            val a = parent.getItemAtPosition(position) as? Aturan ?: return@setOnItemClickListener
            startActivity(
                Intent(this, RuleEditActivity::class.java)
                    .putExtra(RuleEditActivity.EXTRA_ID, a.id)
            )
        }
    }

    override fun onResume() {
        super.onResume()
        val aktif = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
            ?.contains(packageName) == true
        txtStatus.text = if (aktif) "Akses notifikasi: AKTIF" else "Akses notifikasi: BELUM AKTIF"

        val daftar = Store.aturan(this)
        adapter.clear()
        adapter.addAll(daftar)
        adapter.notifyDataSetChanged()
        txtKosong.visibility = if (daftar.isEmpty()) View.VISIBLE else View.GONE
    }

    override fun onPause() {
        super.onPause()
        Store.setJedaMenit(this, (editJeda.text.toString().toIntOrNull() ?: 5).coerceAtLeast(0))
        Store.setUsiaMaksMenit(this, (editUsia.text.toString().toIntOrNull() ?: 2).coerceAtLeast(0))
    }

    private fun ringkas(a: Aturan): String {
        val lingkup = when (a.cakupan) {
            Cakupan.PRIBADI -> "Pribadi"
            Cakupan.GRUP -> if (a.grup.isEmpty()) "Grup (belum dipilih)" else "Grup (${a.grup.size})"
            Cakupan.KEDUANYA ->
                if (a.grup.isEmpty()) "Pribadi + grup (belum dipilih)" else "Pribadi + grup (${a.grup.size})"
        }
        return "$lingkup • ${a.balasan.replace("\n", " ").take(60)}"
    }
}
