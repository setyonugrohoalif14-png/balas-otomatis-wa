package com.lip.balasotomatis

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var daftar: MutableList<Aturan>
    private lateinit var adapter: ArrayAdapter<String>
    private lateinit var txtStatus: TextView
    private lateinit var editJeda: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val switchAktif = findViewById<Switch>(R.id.switchAktif)
        val switchGrup = findViewById<Switch>(R.id.switchGrup)
        val btnAkses = findViewById<Button>(R.id.btnAkses)
        val btnTambah = findViewById<Button>(R.id.btnTambah)
        val editKata = findViewById<EditText>(R.id.editKata)
        val editBalasan = findViewById<EditText>(R.id.editBalasan)
        val list = findViewById<ListView>(R.id.listAturan)
        txtStatus = findViewById(R.id.txtStatusAkses)
        editJeda = findViewById(R.id.editJeda)

        switchAktif.isChecked = Store.aktif(this)
        switchGrup.isChecked = Store.balasGrup(this)
        editJeda.setText(Store.jedaMenit(this).toString())

        switchAktif.setOnCheckedChangeListener { _, v -> Store.setAktif(this, v) }
        switchGrup.setOnCheckedChangeListener { _, v -> Store.setBalasGrup(this, v) }

        btnAkses.setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }

        daftar = Store.aturan(this)
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, ArrayList<String>())
        list.adapter = adapter
        segarkanDaftar()

        btnTambah.setOnClickListener {
            val kata = editKata.text.toString().trim()
            val balasan = editBalasan.text.toString().trim()
            if (kata.isEmpty() || balasan.isEmpty()) {
                Toast.makeText(this, "Kata kunci dan balasan wajib diisi", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            daftar.add(Aturan(kata, balasan))
            Store.simpanAturan(this, daftar)
            editKata.text.clear()
            editBalasan.text.clear()
            segarkanDaftar()
        }

        list.setOnItemClickListener { _, _, posisi, _ ->
            daftar.removeAt(posisi)
            Store.simpanAturan(this, daftar)
            segarkanDaftar()
        }
    }

    override fun onResume() {
        super.onResume()
        val aktif = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
            ?.contains(packageName) == true
        txtStatus.text = if (aktif) "Akses notifikasi: AKTIF" else "Akses notifikasi: BELUM AKTIF"
    }

    override fun onPause() {
        super.onPause()
        val jeda = editJeda.text.toString().toIntOrNull() ?: 5
        Store.setJedaMenit(this, jeda.coerceAtLeast(0))
    }

    private fun segarkanDaftar() {
        adapter.clear()
        adapter.addAll(daftar.map { "\"${it.kata}\"  →  ${it.balasan}" })
        adapter.notifyDataSetChanged()
    }
}
