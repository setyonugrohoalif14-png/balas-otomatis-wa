package com.lip.balasotomatis

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Aturan(val kata: String, val balasan: String)

object Store {
    private const val PREF = "balas_otomatis"
    private const val K_ATURAN = "aturan"
    private const val K_AKTIF = "aktif"
    private const val K_GRUP = "grup"
    private const val K_JEDA = "jeda_menit"

    private fun prefs(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun aturan(c: Context): MutableList<Aturan> {
        val hasil = mutableListOf<Aturan>()
        val json = prefs(c).getString(K_ATURAN, "[]") ?: "[]"
        val arr = JSONArray(json)
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            hasil.add(Aturan(o.getString("kata"), o.getString("balasan")))
        }
        return hasil
    }

    fun simpanAturan(c: Context, daftar: List<Aturan>) {
        val arr = JSONArray()
        daftar.forEach {
            arr.put(JSONObject().put("kata", it.kata).put("balasan", it.balasan))
        }
        prefs(c).edit().putString(K_ATURAN, arr.toString()).apply()
    }

    fun aktif(c: Context) = prefs(c).getBoolean(K_AKTIF, true)
    fun setAktif(c: Context, v: Boolean) = prefs(c).edit().putBoolean(K_AKTIF, v).apply()

    fun balasGrup(c: Context) = prefs(c).getBoolean(K_GRUP, false)
    fun setBalasGrup(c: Context, v: Boolean) = prefs(c).edit().putBoolean(K_GRUP, v).apply()

    fun jedaMenit(c: Context) = prefs(c).getInt(K_JEDA, 5)
    fun setJedaMenit(c: Context, v: Int) = prefs(c).edit().putInt(K_JEDA, v).apply()
}
