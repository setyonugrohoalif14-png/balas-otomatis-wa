package com.lip.balasotomatis

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

enum class Cakupan { PRIBADI, GRUP, KEDUANYA }

data class Aturan(
    val id: String,
    val kata: String,
    val balasan: String,
    val cakupan: Cakupan = Cakupan.PRIBADI,
    val grup: List<String> = emptyList(),
    val aktif: Boolean = true
)

object Store {
    private const val PREF = "balas_otomatis"
    private const val K_ATURAN = "aturan"
    private const val K_AKTIF = "aktif"
    private const val K_JEDA = "jeda_menit"
    private const val K_USIA = "usia_maks_menit"
    private const val K_GRUP_TERLIHAT = "grup_terlihat"
    private const val MAKS_GRUP_TERLIHAT = 100

    private fun prefs(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun idBaru(): String = UUID.randomUUID().toString()

    // ---------- Aturan ----------

    @Synchronized
    fun aturan(c: Context): MutableList<Aturan> {
        val hasil = mutableListOf<Aturan>()
        val arr = try {
            JSONArray(prefs(c).getString(K_ATURAN, "[]") ?: "[]")
        } catch (e: Exception) {
            JSONArray()
        }
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val cakupan = try {
                Cakupan.valueOf(o.optString("cakupan", "PRIBADI"))
            } catch (e: Exception) {
                Cakupan.PRIBADI
            }
            val grupArr = o.optJSONArray("grup") ?: JSONArray()
            val grup = (0 until grupArr.length()).map { grupArr.getString(it) }
            hasil.add(
                Aturan(
                    id = o.optString("id").ifBlank { idBaru() },
                    kata = o.optString("kata"),
                    balasan = o.optString("balasan"),
                    cakupan = cakupan,
                    grup = grup,
                    aktif = o.optBoolean("aktif", true)
                )
            )
        }
        return hasil
    }

    @Synchronized
    private fun tulis(c: Context, daftar: List<Aturan>) {
        val arr = JSONArray()
        daftar.forEach { a ->
            arr.put(
                JSONObject()
                    .put("id", a.id)
                    .put("kata", a.kata)
                    .put("balasan", a.balasan)
                    .put("cakupan", a.cakupan.name)
                    .put("grup", JSONArray(a.grup))
                    .put("aktif", a.aktif)
            )
        }
        prefs(c).edit().putString(K_ATURAN, arr.toString()).apply()
    }

    @Synchronized
    fun simpan(c: Context, a: Aturan) {
        val daftar = aturan(c)
        val idx = daftar.indexOfFirst { it.id == a.id }
        if (idx >= 0) daftar[idx] = a else daftar.add(a)
        tulis(c, daftar)
    }

    @Synchronized
    fun hapus(c: Context, id: String) {
        tulis(c, aturan(c).filter { it.id != id })
    }

    fun cari(c: Context, id: String): Aturan? = aturan(c).firstOrNull { it.id == id }

    // ---------- Pengaturan ----------

    fun aktif(c: Context) = prefs(c).getBoolean(K_AKTIF, true)
    fun setAktif(c: Context, v: Boolean) = prefs(c).edit().putBoolean(K_AKTIF, v).apply()

    fun jedaMenit(c: Context) = prefs(c).getInt(K_JEDA, 5)
    fun setJedaMenit(c: Context, v: Int) = prefs(c).edit().putInt(K_JEDA, v).apply()

    fun usiaMaksMenit(c: Context) = prefs(c).getInt(K_USIA, 2)
    fun setUsiaMaksMenit(c: Context, v: Int) = prefs(c).edit().putInt(K_USIA, v).apply()

    // ---------- Grup yang pernah terdeteksi ----------

    @Synchronized
    fun grupTerlihat(c: Context): List<String> {
        val arr = try {
            JSONArray(prefs(c).getString(K_GRUP_TERLIHAT, "[]") ?: "[]")
        } catch (e: Exception) {
            JSONArray()
        }
        return (0 until arr.length()).map { arr.getString(it) }
    }

    @Synchronized
    fun catatGrup(c: Context, nama: String) {
        val lama = grupTerlihat(c)
        if (lama.firstOrNull() == nama) return
        val baru = (listOf(nama) + lama.filter { !it.equals(nama, ignoreCase = true) })
            .take(MAKS_GRUP_TERLIHAT)
        prefs(c).edit().putString(K_GRUP_TERLIHAT, JSONArray(baru).toString()).apply()
    }
}
