package com.lip.balasotomatis

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class RuleEditActivity : Activity() {

    companion object {
        const val EXTRA_ID = "id"
    }

    private var aturanId: String = Store.idBaru()
    private var sedangMengubah = false
    private val grupTerpilih = linkedSetOf<String>()

    private lateinit var editKata: EditText
    private lateinit var editBalasan: EditText
    private lateinit var radioCakupan: RadioGroup
    private lateinit var boxGrup: View
    private lateinit var txtGrup: TextView
    private lateinit var switchAturanAktif: Switch

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_rule_edit)

        editKata = findViewById(R.id.editKata)
        editBalasan = findViewById(R.id.editBalasan)
        radioCakupan = findViewById(R.id.radioCakupan)
        boxGrup = findViewById(R.id.boxGrup)
        txtGrup = findViewById(R.id.txtGrup)
        switchAturanAktif = findViewById(R.id.switchAturanAktif)
        val btnPilihGrup = findViewById<Button>(R.id.btnPilihGrup)
        val btnSimpan = findViewById<Button>(R.id.btnSimpan)
        val btnHapus = findViewById<Button>(R.id.btnHapus)

        val idLama = intent.getStringExtra(EXTRA_ID)
        val lama = if (idLama != null) Store.cari(this, idLama) else null
        if (lama != null) {
            sedangMengubah = true
            aturanId = lama.id
            editKata.setText(lama.kata)
            editBalasan.setText(lama.balasan)
            switchAturanAktif.isChecked = lama.aktif
            grupTerpilih.addAll(lama.grup)
            radioCakupan.check(
                when (lama.cakupan) {
                    Cakupan.PRIBADI -> R.id.radioPribadi
                    Cakupan.GRUP -> R.id.radioGrup
                    Cakupan.KEDUANYA -> R.id.radioKeduanya
                }
            )
            title = "Ubah aturan"
        } else {
            radioCakupan.check(R.id.radioPribadi)
            switchAturanAktif.isChecked = true
            title = "Aturan baru"
        }

        // Tombol hapus hanya ada saat mengubah aturan, dan selalu minta konfirmasi
        btnHapus.visibility = if (sedangMengubah) View.VISIBLE else View.GONE

        radioCakupan.setOnCheckedChangeListener { _, _ -> perbaruiTampilan() }
        btnPilihGrup.setOnClickListener { pilihGrup() }
        btnSimpan.setOnClickListener { simpan() }
        btnHapus.setOnClickListener { konfirmasiHapus() }

        perbaruiTampilan()
    }

    private fun cakupanSaatIni(): Cakupan = when (radioCakupan.checkedRadioButtonId) {
        R.id.radioGrup -> Cakupan.GRUP
        R.id.radioKeduanya -> Cakupan.KEDUANYA
        else -> Cakupan.PRIBADI
    }

    private fun perbaruiTampilan() {
        boxGrup.visibility = if (cakupanSaatIni() == Cakupan.PRIBADI) View.GONE else View.VISIBLE
        txtGrup.text = if (grupTerpilih.isEmpty()) {
            "Belum ada grup dipilih"
        } else {
            grupTerpilih.joinToString("\n") { "• $it" }
        }
    }

    private fun simpan() {
        val kata = editKata.text.toString().trim()
        val balasan = editBalasan.text.toString().trim()
        val cakupan = cakupanSaatIni()

        if (kata.isEmpty() || balasan.isEmpty()) {
            Toast.makeText(this, "Kata kunci dan balasan wajib diisi", Toast.LENGTH_SHORT).show()
            return
        }
        if (cakupan != Cakupan.PRIBADI && grupTerpilih.isEmpty()) {
            Toast.makeText(this, "Pilih minimal satu grup", Toast.LENGTH_SHORT).show()
            return
        }

        Store.simpan(
            this,
            Aturan(
                id = aturanId,
                kata = kata,
                balasan = balasan,
                cakupan = cakupan,
                grup = if (cakupan == Cakupan.PRIBADI) emptyList() else grupTerpilih.toList(),
                aktif = switchAturanAktif.isChecked
            )
        )
        finish()
    }

    private fun konfirmasiHapus() {
        AlertDialog.Builder(this)
            .setTitle("Hapus aturan?")
            .setMessage(
                "Aturan \"${editKata.text}\" akan dihapus permanen. " +
                    "Kalau hanya ingin berhenti sementara, matikan saklar \"Aturan aktif\" lalu Simpan."
            )
            .setNegativeButton("Batal", null)
            .setPositiveButton("Hapus") { _, _ ->
                Store.hapus(this, aturanId)
                finish()
            }
            .show()
    }

    private fun pilihGrup() {
        val semua = (Store.grupTerlihat(this) + grupTerpilih)
            .distinctBy { it.lowercase() }
            .sortedBy { it.lowercase() }

        if (semua.isEmpty()) {
            AlertDialog.Builder(this)
                .setTitle("Pilih grup")
                .setMessage(
                    "Belum ada grup terdeteksi. Nama grup muncul di sini setelah ada pesan grup " +
                        "masuk saat aplikasi ini aktif. Kamu juga bisa mengetik nama grup secara manual."
                )
                .setNeutralButton("Tambah manual") { _, _ -> tambahManual() }
                .setPositiveButton("Tutup", null)
                .show()
            return
        }

        val centang = BooleanArray(semua.size) { i ->
            grupTerpilih.any { it.equals(semua[i], ignoreCase = true) }
        }
        AlertDialog.Builder(this)
            .setTitle("Pilih grup")
            .setMultiChoiceItems(semua.toTypedArray(), centang) { _, i, dipilih ->
                centang[i] = dipilih
            }
            .setNeutralButton("Tambah manual") { _, _ ->
                terapkan(semua, centang)
                tambahManual()
            }
            .setNegativeButton("Batal", null)
            .setPositiveButton("Selesai") { _, _ -> terapkan(semua, centang) }
            .show()
    }

    private fun terapkan(semua: List<String>, centang: BooleanArray) {
        grupTerpilih.clear()
        semua.forEachIndexed { i, nama -> if (centang[i]) grupTerpilih.add(nama) }
        perbaruiTampilan()
    }

    private fun tambahManual() {
        val input = EditText(this)
        input.hint = "Nama grup persis seperti di WhatsApp"
        AlertDialog.Builder(this)
            .setTitle("Tambah grup")
            .setView(input)
            .setNegativeButton("Batal", null)
            .setPositiveButton("Tambah") { _, _ ->
                val nama = input.text.toString().trim()
                if (nama.isNotEmpty()) {
                    grupTerpilih.add(nama)
                    perbaruiTampilan()
                }
            }
            .show()
    }
}
