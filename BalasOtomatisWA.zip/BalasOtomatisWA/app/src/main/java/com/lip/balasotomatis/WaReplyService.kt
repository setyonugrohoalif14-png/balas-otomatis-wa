package com.lip.balasotomatis

import android.app.Notification
import android.app.RemoteInput
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log

class WaReplyService : NotificationListenerService() {

    private data class Pesan(
        val namaChat: String,
        val grup: Boolean,
        val teks: String,
        val waktu: Long
    )

    private val paketWa = setOf("com.whatsapp", "com.whatsapp.w4b")
    private val handler = Handler(Looper.getMainLooper())

    // Waktu balasan terakhir per chat
    private val terakhirDibalas = mutableMapOf<String, Long>()

    // Pesan yang sudah pernah diproses, supaya satu pesan tidak dibalas dua kali
    private val sudahDiproses = LinkedHashSet<String>()

    // Slot waktu berikutnya di antrean kirim (uptime)
    private var slotBerikut = 0L

    // Akhiran seperti " (3 pesan)" atau " (2 messages)" pada judul notifikasi
    private val akhiranJumlah =
        Regex("""\s*\(\d+\s+(pesan|messages?)( baru| new)?\)$""", RegexOption.IGNORE_CASE)

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName !in paketWa) return
        val notif = sbn.notification
        // Lewati notifikasi ringkasan ("3 pesan dari 2 obrolan")
        if ((notif.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return

        val pesan = bacaPesan(notif) ?: return

        // Catat nama grup agar bisa dipilih di layar aturan
        if (pesan.grup) Store.catatGrup(this, pesan.namaChat)

        if (!Store.aktif(this)) return

        // 1. Satu pesan hanya diproses sekali
        val kunci = "${pesan.namaChat}|${pesan.waktu}|${pesan.teks}"
        if (!sudahDiproses.add(kunci)) return
        if (sudahDiproses.size > 300) {
            val iter = sudahDiproses.iterator()
            iter.next()
            iter.remove()
        }

        val sekarang = System.currentTimeMillis()

        // 2. Abaikan pesan lama (misalnya notifikasi telat karena HP lag atau offline)
        val usiaMaksMs = Store.usiaMaksMenit(this) * 60_000L
        if (usiaMaksMs > 0 && pesan.waktu > 0 && sekarang - pesan.waktu > usiaMaksMs) return

        val daftar = Store.aturan(this)

        // 3. Jangan membalas balasan kita sendiri
        if (daftar.any { it.balasan.trim() == pesan.teks }) return

        val teksKecil = pesan.teks.lowercase()
        val aturan = daftar.firstOrNull { cocok(it, pesan, teksKecil) } ?: return

        // 4. Jeda per chat
        val jedaMs = Store.jedaMenit(this) * 60_000L
        val terakhir = terakhirDibalas[pesan.namaChat] ?: 0L
        if (sekarang - terakhir < jedaMs) return

        val aksi = notif.actions?.firstOrNull { it.remoteInputs?.isNotEmpty() == true } ?: return

        // 5. Antrean: balasan dikirim satu per satu dengan jarak waktu, dan antrean dibatasi
        val uptime = SystemClock.uptimeMillis()
        if (slotBerikut - uptime > BATAS_ANTREAN_MS) return
        val waktuKirim = maxOf(uptime + JEDA_AWAL_MS, slotBerikut)
        slotBerikut = waktuKirim + JEDA_ANTAR_BALASAN_MS
        terakhirDibalas[pesan.namaChat] = sekarang
        handler.postAtTime({ kirim(aksi, aturan.balasan) }, waktuKirim)
    }

    private fun cocok(a: Aturan, p: Pesan, teksKecil: String): Boolean {
        if (!a.aktif || a.kata.isBlank()) return false
        if (!teksKecil.contains(a.kata.trim().lowercase())) return false
        val grupDipilih = a.grup.any { it.trim().equals(p.namaChat, ignoreCase = true) }
        return when (a.cakupan) {
            Cakupan.PRIBADI -> !p.grup
            Cakupan.GRUP -> p.grup && grupDipilih
            Cakupan.KEDUANYA -> !p.grup || grupDipilih
        }
    }

    @Suppress("DEPRECATION")
    private fun bacaPesan(notif: Notification): Pesan? {
        val extras = notif.extras
        val judul = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()
        val judulPercakapan = extras.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)?.toString()
        val grup = extras.getBoolean(Notification.EXTRA_IS_GROUP_CONVERSATION, false) ||
            !judulPercakapan.isNullOrBlank()

        val namaMentah = (if (grup) (judulPercakapan ?: judul) else judul) ?: return null
        val nama = namaMentah.replace(akhiranJumlah, "").trim()
        if (nama.isEmpty()) return null

        // Ambil pesan paling baru dari gaya notifikasi percakapan
        var teks: String? = null
        var waktu = 0L
        val daftarPesan = extras.getParcelableArray(Notification.EXTRA_MESSAGES)
        val terakhir = daftarPesan?.lastOrNull() as? Bundle
        if (terakhir != null) {
            teks = terakhir.getCharSequence("text")?.toString()
            waktu = terakhir.getLong("time", 0L)
        }
        if (teks.isNullOrBlank()) {
            teks = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()
        }
        if (teks.isNullOrBlank()) return null
        if (waktu == 0L) waktu = notif.`when`

        return Pesan(nama, grup, teks.trim(), waktu)
    }

    private fun kirim(aksi: Notification.Action, balasan: String) {
        try {
            val remoteInputs = aksi.remoteInputs ?: return
            val intent = Intent()
            val hasil = Bundle().apply {
                putCharSequence(remoteInputs[0].resultKey, balasan)
            }
            RemoteInput.addResultsToIntent(remoteInputs, intent, hasil)
            aksi.actionIntent.send(applicationContext, 0, intent)
        } catch (e: Exception) {
            Log.e(TAG, "Gagal membalas", e)
        }
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        try {
            requestRebind(ComponentName(this, WaReplyService::class.java))
        } catch (e: Exception) {
            Log.e(TAG, "Gagal menyambung ulang", e)
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    companion object {
        private const val TAG = "WaReplyService"
        private const val JEDA_AWAL_MS = 1500L
        private const val JEDA_ANTAR_BALASAN_MS = 2500L
        private const val BATAS_ANTREAN_MS = 20_000L
    }
}
