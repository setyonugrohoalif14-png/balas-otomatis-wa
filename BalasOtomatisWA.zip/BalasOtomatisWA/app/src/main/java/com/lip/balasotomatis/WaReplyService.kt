package com.lip.balasotomatis

import android.app.Notification
import android.app.RemoteInput
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log

class WaReplyService : NotificationListenerService() {

    // Waktu balasan terakhir per kontak, untuk mencegah balasan beruntun
    private val terakhirDibalas = mutableMapOf<String, Long>()

    private val paketWa = setOf("com.whatsapp", "com.whatsapp.w4b")

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName !in paketWa) return
        if (!Store.aktif(this)) return

        val notif = sbn.notification
        // Lewati notifikasi ringkasan ("3 pesan dari 2 obrolan")
        if (notif.flags and Notification.FLAG_GROUP_SUMMARY != 0) return

        val extras = notif.extras
        val pengirim = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val teks = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.lowercase() ?: return

        // Lewati grup kecuali diizinkan
        val grup = extras.getBoolean("android.isGroupConversation", false) ||
            extras.getCharSequence("android.conversationTitle") != null
        if (grup && !Store.balasGrup(this)) return

        // Cek jeda per kontak
        val sekarang = System.currentTimeMillis()
        val jedaMs = Store.jedaMenit(this) * 60_000L
        val terakhir = terakhirDibalas[pengirim] ?: 0L
        if (sekarang - terakhir < jedaMs) return

        // Cocokkan kata kunci
        val aturan = Store.aturan(this).firstOrNull { teks.contains(it.kata.lowercase()) } ?: return

        // Cari tombol "Balas" pada notifikasi
        val aksi = notif.actions?.firstOrNull { it.remoteInputs?.isNotEmpty() == true } ?: return
        val remoteInputs = aksi.remoteInputs

        try {
            val intent = Intent()
            val hasil = Bundle().apply {
                putCharSequence(remoteInputs[0].resultKey, aturan.balasan)
            }
            RemoteInput.addResultsToIntent(remoteInputs, intent, hasil)
            aksi.actionIntent.send(applicationContext, 0, intent)
            terakhirDibalas[pengirim] = sekarang
        } catch (e: Exception) {
            Log.e("WaReplyService", "Gagal membalas", e)
        }
    }
}
